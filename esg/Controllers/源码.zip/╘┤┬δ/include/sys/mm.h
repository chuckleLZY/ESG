#ifndef _MM_H_
#define _MM_H_


// PUBLIC int mm_fork(void);
// PUBLIC int mm_exec(char* name);
// PUBLIC void mm_wait();
// PUBLIC u32 mm_sleep(int seconds);
// PUBLIC void mm_exit(int status);


#endif
