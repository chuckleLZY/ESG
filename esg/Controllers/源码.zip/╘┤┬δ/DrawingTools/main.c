/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            main.c
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
													Kaibin Zhou,2020
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#include "DrawingTools.h"
#include "type.h"
#include "config.h"
#include "stdio.h"
#include "const.h"
#include "protect.h"
#include "string.h"
#include "fs.h"
#include "proc.h"
#include "tty.h"
#include "console.h"
#include "global.h"
#include "keyboard.h"
#include "proto.h"


PUBLIC void task_vm()
{
	while (1) {
		send_recv(RECEIVE, ANY, &vm_msg);
		int src = vm_msg.source;
		int reply = 1;

		int msgtype = vm_msg.type;

		switch (msgtype) {
		case PRINTLETTER:
			do_vm_pl();
			break;
		case OP_PIXEL:
			do_drawPixel();
			break;
		case LINE:	
			do_drawLine();
			break;
		case RECTAN:
			do_drawBox();
			break;
		case CIRCLE:
			do_drawCircle();
			break;






        case DRAW:
            vm_msg.RETVAL=do_drawBMP();
			break;
		case CLEAR:
            do_clear();
			break;	




		
		case MODE:
			do_changeColorMode();
			break;
		default:
			dump_msg("GRAPHICS::unknown msg", &vm_msg);
			assert(0);
			break;
		}

		if (reply) {
			vm_msg.type = SYSCALL_RET;
			send_recv(SEND, src, &vm_msg);
		}
	}
}


int do_drawBMP()
{
	char pathname[MAX_PATH];

	int name_len =  vm_msg.NAME_LEN;	/* length of filename */
	int src = vm_msg.source;	/* caller proc nr. */
	assert(name_len < MAX_PATH);
	phys_copy((void*)va2la(TASK_VM, pathname),
		  (void*)va2la(src, vm_msg.PATHNAME),
		  name_len);
	pathname[name_len] = 0;

    return readBMP(pathname);
}


int do_topBar()
{
	char user[MAX_PATH];

	int name_len =  vm_msg.NAME_LEN;	/* length of filename */
	int src = vm_msg.source;	/* caller proc nr. */
	assert(name_len < MAX_PATH);
	phys_copy((void*)va2la(TASK_VM, user),
		  (void*)va2la(src, vm_msg.PATHNAME),
		  name_len);
	user[name_len] = 0;

    updateTopbar(user);
    return 1;
}

void do_clear()
{
	clearScreen();
}


void do_vm_pl()
{
	unsigned char _s[MAX_PATH];
	assert(vm_msg.STRINGLEN < MAX_PATH);
	phys_copy((void*)va2la(TASK_VM, _s),(void*)va2la(vm_msg.source, vm_msg.TARGETSTRING),vm_msg.STRINGLEN);
	_s[vm_msg.STRINGLEN] = 0;
	putfonts8_asc(vm_msg.LETTERPOSITIONX, vm_msg.LETTERPOSITIONY, vm_msg.LETTERCOLOR, _s);
}
/*****************************************************************************
 *                                drawPixel
 *****************************************************************************/
int do_drawPixel()
{
	int pos_x = vm_msg.PIXELPOSX;
	int pos_y = vm_msg.PIXELPOSY;
	char _color = vm_msg.PIXELCOLOR;
	return pixel(pos_x,pos_y,_color);
}
/*****************************************************************************
 *                                drawBox
 *****************************************************************************/
void do_drawBox()
{
	boxfill8(SCREEN_WIDTH,vm_msg.RCOLOR,vm_msg.SPOSX,vm_msg.SPOSY,
	vm_msg.EPOSX,vm_msg.EPOSY);

}
/*****************************************************************************
 *                                drawLine
 *****************************************************************************/
void do_drawLine()
{
	char c = vm_msg.LCOLOR;
	int x1 = vm_msg.SPOSX;
	int y1 = vm_msg.SPOSY;
	int x2 = vm_msg.EPOSX;
	int y2 = vm_msg.EPOSY;
	int i,j;
	if(x1==x2)		//竖线
	{
		if(y1<y2)
		{
			for(i=y1;i<=y2;i++)
				pixel(x1,i,c);
		}
		else
		{
			for(i=y2;i<=y1;i++)
				pixel(x1,i,c);	
		}
		return;
	}
	else if(y1==y2)	//横线
	{
		if(x1<x2)
		{
			for(i=x1;i<=x2;i++)
				pixel(i,y1,c);
		}
		else
		{
			for(i=x2;i<=x1;i++)
				pixel(i,y1,c);
		}		
		return;
	}
	else			//斜线
	{
		return;
	}
	

}

/*****************************************************************************
 *                                drawCircle
 *****************************************************************************/
void do_drawCircle()
{
	int x=vm_msg.CIRCENTERX;
	int y=vm_msg.CIRCENTERY;
	int radius=vm_msg.RADIUS;
	char c=vm_msg.CCOLOR;
	int l=x-radius;
	int r=x+radius;
	int u=y-radius;
	int d=y+radius;
	l=(l>=0)?l:0;
	r=(r<SCREEN_WIDTH)?r:SCREEN_WIDTH-1;
	u=(u>=0)?u:0;
	d=(d<SCREEN_HEIGHT)?d:SCREEN_HEIGHT-1;
	int i,j;
	for(i=l;i<=r;i++)
	{
		for(j=u;j<=d;j++)
		{
			int dis=(i-x)*(i-x)+(j-y)*(j-y);
			if(dis<=radius*radius)
				pixel(i,j,c);
		}
	}
}

void do_changeColorMode()
{
	if(colorMode==1)
	{
		grayPalette();
		colorMode=0;
	}
	else
	{
		colorPalette();
		colorMode=1;
	}
	
}

